import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-layout-tools',
  templateUrl: './layout-tools.component.html',
  styleUrls: ['./layout-tools.component.scss']
})
export class LayoutToolsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
