import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-layout-side',
  templateUrl: './layout-side.component.html',
  styleUrls: ['./layout-side.component.scss']
})
export class LayoutSideComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
