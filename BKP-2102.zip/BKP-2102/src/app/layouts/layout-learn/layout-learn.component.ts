import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-layout-learn',
  templateUrl: './layout-learn.component.html',
  styleUrls: ['./layout-learn.component.scss']
})
export class LayoutLearnComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
