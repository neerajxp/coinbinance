import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-layout-kinu',
  templateUrl: './layout-kinu.component.html',
  styleUrls: ['./layout-kinu.component.scss']
})
export class LayoutKinuComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
