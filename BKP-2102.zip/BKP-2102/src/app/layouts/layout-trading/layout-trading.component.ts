import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-layout-trading',
  templateUrl: './layout-trading.component.html',
  styleUrls: ['./layout-trading.component.scss']
})
export class LayoutTradingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
