import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-headerlearn',
  templateUrl: './headerlearn.component.html',
  styleUrls: ['./headerlearn.component.scss']
})
export class HeaderlearnComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
