import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header-kinu',
  templateUrl: './header-kinu.component.html',
  styleUrls: ['./header-kinu.component.scss']
})
export class HeaderKinuComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
