export class NewsModel
{        
    constructor
    (
    public source: string,
    public id: number,        
    public newssource: string,
    public headline: string,
    public content: string,
    public newsurl: string,
    public thumbnail: string,      
    public published: string,
    public hrsago: number,
    public keywords: string,
    public author: string,
    ){}         
}
 