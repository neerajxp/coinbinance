import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-coinwatch',
  templateUrl: './coinwatch.component.html',
  styleUrls: ['./coinwatch.component.scss']
})
export class CoinwatchComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
