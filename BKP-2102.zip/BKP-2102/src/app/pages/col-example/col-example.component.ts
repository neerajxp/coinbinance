import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-col-example',
  templateUrl: './col-example.component.html',
  styleUrls: ['./col-example.component.scss']
})
export class ColExampleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
