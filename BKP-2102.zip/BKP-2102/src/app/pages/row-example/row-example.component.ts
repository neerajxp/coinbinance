import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-row-example',
  templateUrl: './row-example.component.html',
  styleUrls: ['./row-example.component.scss']
})
export class RowExampleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
