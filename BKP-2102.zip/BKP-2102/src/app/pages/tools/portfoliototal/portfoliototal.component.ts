import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-portfoliototal',
  templateUrl: './portfoliototal.component.html',
  styleUrls: ['./portfoliototal.component.scss']
})
export class PortfoliototalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
