import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-a-crypto-for-here',
  templateUrl: './a-crypto-for-here.component.html',
  styleUrls: ['./a-crypto-for-here.component.scss']
})
export class ACryptoForHereComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
